import React from 'react';
import { useCursor } from '../hooks/useCursor';

export const CustomCursor: React.FC = () => {
  const { position, isClicking } = useCursor();

  return (
    <>
      <div
        className="custom-cursor"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: isClicking ? 'translate(-50%, -50%) scale(0.8)' : 'translate(-50%, -50%) scale(1)',
        }}
      />
      <div
        className="custom-cursor-dot"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
        }}
      />
    </>
  );
};
