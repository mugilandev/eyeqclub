import React from 'react';
import { User, Mail, Award, LogOut, Linkedin, Instagram, MessageCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface ProfilePageProps {
  onLogout: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onLogout }) => {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    onLogout();
  };

  if (!user) return null;

  return (
    <div className="page-container">
      <section className="profile-section">
        <div className="profile-container">
          <div className="profile-header">
            <div className="profile-avatar-large">
              {user.fullName.charAt(0).toUpperCase()}
            </div>
            <h2 className="profile-name">{user.fullName}</h2>
            <p className="profile-role">{user.role}</p>
          </div>

          <div className="profile-info">
            <div className="profile-info-item">
              <Mail className="profile-info-icon" />
              <div>
                <h4>Email</h4>
                <p>{user.email}</p>
              </div>
            </div>

            <div className="profile-info-item">
              <Award className="profile-info-icon" />
              <div>
                <h4>Points</h4>
                <p>{user.points} points</p>
              </div>
            </div>

            <div className="profile-info-item">
              <User className="profile-info-icon" />
              <div>
                <h4>Member Type</h4>
                <p className="capitalize">{user.role}</p>
              </div>
            </div>
          </div>

          <div className="profile-social">
            <h3>Connect Social Media</h3>
            <div className="profile-social-links">
              <button className="profile-social-btn">
                <Linkedin size={20} />
                <span>LinkedIn</span>
              </button>
              <button className="profile-social-btn">
                <Instagram size={20} />
                <span>Instagram</span>
              </button>
              <button className="profile-social-btn">
                <MessageCircle size={20} />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>

          <button className="logout-button" onClick={handleLogout}>
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </section>
    </div>
  );
};
