import React from 'react';
import { Trophy, Medal, Award, TrendingUp } from 'lucide-react';

interface LeaderEntry {
  rank: number;
  name: string;
  points: number;
  activities: number;
  trend: 'up' | 'down' | 'same';
}

export const LeaderboardPage: React.FC = () => {
  const leaders: LeaderEntry[] = [
    { rank: 1, name: 'Priya Sharma', points: 2450, activities: 45, trend: 'up' },
    { rank: 2, name: 'Arjun Kumar', points: 2280, activities: 42, trend: 'up' },
    { rank: 3, name: 'Sneha Patel', points: 2150, activities: 38, trend: 'same' },
    { rank: 4, name: 'Rahul Verma', points: 1980, activities: 35, trend: 'down' },
    { rank: 5, name: 'Ananya Singh', points: 1850, activities: 32, trend: 'up' },
    { rank: 6, name: 'Vikram Reddy', points: 1720, activities: 30, trend: 'up' },
    { rank: 7, name: 'Kavya Nair', points: 1650, activities: 28, trend: 'same' },
    { rank: 8, name: 'Aditya Gupta', points: 1580, activities: 26, trend: 'down' },
    { rank: 9, name: 'Meera Iyer', points: 1480, activities: 24, trend: 'up' },
    { rank: 10, name: 'Sanjay Desai', points: 1420, activities: 22, trend: 'up' },
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="rank-icon gold" size={32} />;
      case 2:
        return <Medal className="rank-icon silver" size={32} />;
      case 3:
        return <Medal className="rank-icon bronze" size={32} />;
      default:
        return <div className="rank-number">{rank}</div>;
    }
  };

  const getTrendIcon = (trend: string) => {
    if (trend === 'up') return <TrendingUp className="trend-up" size={16} />;
    if (trend === 'down') return <TrendingUp className="trend-down" size={16} />;
    return null;
  };

  return (
    <div className="page-container">
      <section className="leaderboard-section">
        <div className="section-header">
          <Award className="section-icon" />
          <h2 className="section-title">Club Leaderboard</h2>
          <p className="section-subtitle">Top performers and active contributors</p>
        </div>

        <div className="leaderboard-stats">
          <div className="stat-box">
            <Trophy className="stat-box-icon" />
            <div className="stat-box-value">150+</div>
            <div className="stat-box-label">Active Members</div>
          </div>
          <div className="stat-box">
            <TrendingUp className="stat-box-icon" />
            <div className="stat-box-value">25K+</div>
            <div className="stat-box-label">Total Points</div>
          </div>
          <div className="stat-box">
            <Award className="stat-box-icon" />
            <div className="stat-box-value">500+</div>
            <div className="stat-box-label">Activities</div>
          </div>
        </div>

        <div className="leaderboard-container">
          <div className="leaderboard-header">
            <span className="header-rank">Rank</span>
            <span className="header-name">Member</span>
            <span className="header-points">Points</span>
            <span className="header-activities">Activities</span>
            <span className="header-trend">Trend</span>
          </div>

          <div className="leaderboard-list">
            {leaders.map((leader) => (
              <div
                key={leader.rank}
                className={`leaderboard-row ${leader.rank <= 3 ? 'top-three' : ''}`}
                style={{ animationDelay: `${leader.rank * 0.05}s` }}
              >
                <div className="row-rank">{getRankIcon(leader.rank)}</div>
                <div className="row-name">
                  <div className="member-avatar">
                    {leader.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <span>{leader.name}</span>
                </div>
                <div className="row-points">
                  <span className="points-value">{leader.points.toLocaleString()}</span>
                  <span className="points-label">pts</span>
                </div>
                <div className="row-activities">{leader.activities}</div>
                <div className="row-trend">{getTrendIcon(leader.trend)}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
