import React, { useState } from 'react';
import { Mail, MapPin, Phone, Send, Linkedin, Instagram, MessageCircle } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Message sent successfully!');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="page-container">
      <section className="contact-section">
        <div className="section-header">
          <Mail className="section-icon" />
          <h2 className="section-title">Get In Touch</h2>
          <p className="section-subtitle">Have questions? We'd love to hear from you.</p>
        </div>

        <div className="contact-grid">
          <div className="contact-info">
            <h3 className="contact-info-title">Contact Information</h3>

            <div className="contact-item">
              <MapPin className="contact-icon" />
              <div>
                <h4>Location</h4>
                <p>SIMATS Campus, Chennai</p>
              </div>
            </div>

            <div className="contact-item">
              <Mail className="contact-icon" />
              <div>
                <h4>Email</h4>
                <p>eyeqclub@simats.edu</p>
              </div>
            </div>

            <div className="contact-item">
              <Phone className="contact-icon" />
              <div>
                <h4>Phone</h4>
                <p>+91 1234567890</p>
              </div>
            </div>

            <div className="social-links-section">
              <h4>Follow Us</h4>
              <div className="social-links-grid">
                <a href="#" className="social-link-card">
                  <Linkedin size={24} />
                  <span>LinkedIn</span>
                </a>
                <a href="#" className="social-link-card">
                  <Instagram size={24} />
                  <span>Instagram</span>
                </a>
                <a href="#" className="social-link-card">
                  <MessageCircle size={24} />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>
          </div>

          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Your name"
              />
            </div>

            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="your.email@example.com"
              />
            </div>

            <div className="form-group">
              <label htmlFor="subject">Subject</label>
              <input
                type="text"
                id="subject"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                required
                placeholder="What's this about?"
              />
            </div>

            <div className="form-group">
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={6}
                placeholder="Your message..."
              />
            </div>

            <button type="submit" className="submit-button">
              <Send size={20} />
              <span>Send Message</span>
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};
