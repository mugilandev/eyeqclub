import React, { useState } from 'react';
import { HelpCircle, ChevronDown } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

export const FAQPage: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQItem[] = [
    {
      question: 'What is EyeQ Club?',
      answer: 'EyeQ Club is a premier innovation and collaboration hub at SIMATS, focusing on computer vision, artificial intelligence, and emerging technologies. We bring together passionate students to work on cutting-edge projects.',
    },
    {
      question: 'How can I join EyeQ Club?',
      answer: 'You can join by creating an account on our website and filling out the membership form. Once approved by our club bearers, you\'ll receive your member ID and can start participating in events and projects.',
    },
    {
      question: 'What activities does the club organize?',
      answer: 'We organize weekly workshops, hackathons, collaborative projects, industry mentorship sessions, and recognition programs. Members also get access to exclusive coding challenges and daily project updates.',
    },
    {
      question: 'Do I need prior experience in computer vision?',
      answer: 'No prior experience is required! We welcome members of all skill levels. Our community is built on learning together, and we provide resources and mentorship to help everyone grow.',
    },
    {
      question: 'How does the leaderboard system work?',
      answer: 'Members earn points through various activities like completing projects, participating in hackathons, helping other members, and contributing to club initiatives. The leaderboard tracks these points and recognizes top contributors.',
    },
    {
      question: 'What are the benefits of membership?',
      answer: 'Members get access to exclusive workshops, mentorship programs, project collaboration opportunities, recognition for achievements, networking with industry professionals, and a certificate of membership.',
    },
    {
      question: 'Can I propose my own project ideas?',
      answer: 'Absolutely! We encourage members to propose and lead their own projects. You can pitch your ideas to the club bearers, and if approved, we\'ll help you form a team and provide resources.',
    },
    {
      question: 'How do I stay updated with club activities?',
      answer: 'Stay connected through our website\'s daily updates section, follow us on social media (LinkedIn, Instagram, WhatsApp), and check your email for event notifications and newsletters.',
    },
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="page-container">
      <section className="faq-section">
        <div className="section-header">
          <HelpCircle className="section-icon" />
          <h2 className="section-title">Frequently Asked Questions</h2>
          <p className="section-subtitle">Everything you need to know about EyeQ Club</p>
        </div>

        <div className="faq-container">
          {faqs.map((faq, index) => (
            <div key={index} className={`faq-item ${openIndex === index ? 'open' : ''}`}>
              <button className="faq-question" onClick={() => toggleFAQ(index)}>
                <span>{faq.question}</span>
                <ChevronDown
                  className={`faq-icon ${openIndex === index ? 'rotated' : ''}`}
                  size={20}
                />
              </button>
              <div className="faq-answer">
                <p>{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
