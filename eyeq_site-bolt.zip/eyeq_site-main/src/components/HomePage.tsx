import React, { useEffect, useState } from 'react';
import { Sparkles, Users, Target, Award, Linkedin, Instagram, MessageCircle } from 'lucide-react';

export const HomePage: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const bearers = [
    { name: 'Club President', role: 'Leadership', image: '👤', color: 'from-cyan-500 to-blue-500' },
    { name: 'Tech Lead', role: 'Development', image: '👤', color: 'from-green-500 to-emerald-500' },
    { name: 'Design Head', role: 'UI/UX', image: '👤', color: 'from-orange-500 to-red-500' },
    { name: 'Event Manager', role: 'Coordination', image: '👤', color: 'from-pink-500 to-rose-500' },
  ];

  const socialLinks = [
    { icon: Linkedin, url: '#', label: 'LinkedIn' },
    { icon: Instagram, url: '#', label: 'Instagram' },
    { icon: MessageCircle, url: '#', label: 'WhatsApp' },
  ];

  return (
    <div className="page-container">
      <section className={`hero-section ${isVisible ? 'visible' : ''}`}>
        <div className="hero-content">
          <div className="hero-logo-container">
            <img src="/white.png" alt="EyeQ Club" className="hero-logo" />
          </div>

          <h1 className="hero-title">
            Welcome to <span className="gradient-text">EyeQ Club</span>
          </h1>

          <p className="hero-subtitle">
            Computer Vision Club – Innovating with Vision & Vibe Coding
          </p>

          <p className="hero-description">
            A premier innovation and collaboration hub at SIMATS, fostering creativity,
            problem-solving, and excellence in computer vision and emerging technologies.
          </p>

          <div className="hero-stats">
            <div className="stat-card">
              <Users className="stat-icon" />
              <div className="stat-value">150+</div>
              <div className="stat-label">Active Members</div>
            </div>
            <div className="stat-card">
              <Target className="stat-icon" />
              <div className="stat-value">50+</div>
              <div className="stat-label">Projects</div>
            </div>
            <div className="stat-card">
              <Award className="stat-icon" />
              <div className="stat-value">25+</div>
              <div className="stat-label">Awards</div>
            </div>
          </div>
        </div>
      </section>

      <section className="proposal-section">
        <div className="section-header">
          <Sparkles className="section-icon" />
          <h2 className="section-title">Club Proposal</h2>
        </div>

        <div className="proposal-content">
          <div className="proposal-card">
            <h3>Our Mission</h3>
            <p>
              To cultivate a community of innovators who push the boundaries of computer
              vision, artificial intelligence, and collaborative problem-solving.
            </p>
          </div>

          <div className="proposal-card">
            <h3>Our Vision</h3>
            <p>
              To become the leading innovation hub in the region, recognized for excellence
              in technical projects, member development, and industry collaboration.
            </p>
          </div>

          <div className="proposal-card">
            <h3>What We Do</h3>
            <p>
              Weekly workshops, hackathons, collaborative projects, industry mentorship,
              and recognition programs that celebrate outstanding contributions.
            </p>
          </div>
        </div>
      </section>

      <section className="bearers-section">
        <div className="section-header">
          <Users className="section-icon" />
          <h2 className="section-title">Club Bearers</h2>
        </div>

        <div className="bearers-grid">
          {bearers.map((bearer, index) => (
            <div key={index} className="bearer-card" style={{ animationDelay: `${index * 0.1}s` }}>
              <div className={`bearer-avatar bg-gradient-to-br ${bearer.color}`}>
                <span className="bearer-image">{bearer.image}</span>
              </div>
              <h3 className="bearer-name">{bearer.name}</h3>
              <p className="bearer-role">{bearer.role}</p>
              <div className="bearer-social">
                {socialLinks.map((social, idx) => (
                  <a key={idx} href={social.url} className="social-link">
                    <social.icon size={18} />
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="updates-section">
        <div className="section-header">
          <Sparkles className="section-icon" />
          <h2 className="section-title">Daily Works Updates</h2>
        </div>

        <div className="updates-feed">
          {[1, 2, 3].map((i) => (
            <div key={i} className="update-card">
              <div className="update-header">
                <div className="update-avatar">A</div>
                <div>
                  <h4 className="update-author">Anonymous Member</h4>
                  <p className="update-time">{i} hours ago</p>
                </div>
              </div>
              <h3 className="update-title">Project Update #{i}</h3>
              <p className="update-description">
                Making great progress on the computer vision module. Implemented real-time
                object detection with 95% accuracy. Team collaboration has been excellent.
              </p>
              <div className="update-tags">
                <span className="tag">Computer Vision</span>
                <span className="tag">AI/ML</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="recognition-section">
        <div className="section-header">
          <Award className="section-icon" />
          <h2 className="section-title">Recognition & Excellence</h2>
        </div>

        <div className="recognition-content">
          <p className="recognition-text">
            At EyeQ Club, we believe in celebrating excellence. Our members consistently
            demonstrate outstanding problem-solving skills, innovative thinking, and
            collaborative spirit. Join us in building the future of technology.
          </p>

          <div className="recognition-highlights">
            <div className="highlight-item">
              <div className="highlight-icon">🏆</div>
              <h4>Outstanding Innovation</h4>
              <p>Recognizing breakthrough projects and ideas</p>
            </div>
            <div className="highlight-item">
              <div className="highlight-icon">🤝</div>
              <h4>Team Collaboration</h4>
              <p>Celebrating effective teamwork and synergy</p>
            </div>
            <div className="highlight-item">
              <div className="highlight-icon">💡</div>
              <h4>Problem Solving</h4>
              <p>Rewarding creative solutions to challenges</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
