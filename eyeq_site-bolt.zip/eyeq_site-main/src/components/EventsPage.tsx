import React from 'react';
import { Calendar, Clock, MapPin, ExternalLink, Users } from 'lucide-react';

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  registrationLink: string;
  attendees: number;
  type: 'hackathon' | 'workshop' | 'competition';
}

export const EventsPage: React.FC = () => {
  const events: Event[] = [
    {
      id: '1',
      title: 'AI/ML Hackathon 2025',
      description: 'A 48-hour intensive hackathon focusing on machine learning applications in computer vision. Build innovative solutions and compete for prizes.',
      date: '2025-11-15',
      time: '09:00 AM',
      location: 'SIMATS Tech Hub',
      registrationLink: '#',
      attendees: 120,
      type: 'hackathon',
    },
    {
      id: '2',
      title: 'Deep Learning Workshop',
      description: 'Hands-on workshop covering neural networks, CNNs, and their applications in computer vision. Suitable for beginners and intermediate learners.',
      date: '2025-11-08',
      time: '02:00 PM',
      location: 'Online',
      registrationLink: '#',
      attendees: 85,
      type: 'workshop',
    },
    {
      id: '3',
      title: 'Code Sprint Competition',
      description: 'Fast-paced coding competition with algorithmic challenges and real-world problem-solving. Top performers win exciting prizes.',
      date: '2025-11-22',
      time: '10:00 AM',
      location: 'SIMATS Campus',
      registrationLink: '#',
      attendees: 150,
      type: 'competition',
    },
    {
      id: '4',
      title: 'Computer Vision Bootcamp',
      description: 'Intensive 3-day bootcamp covering image processing, object detection, and facial recognition technologies.',
      date: '2025-12-01',
      time: '09:00 AM',
      location: 'SIMATS Lab 3',
      registrationLink: '#',
      attendees: 60,
      type: 'workshop',
    },
  ];

  const getEventTypeClass = (type: string) => {
    switch (type) {
      case 'hackathon':
        return 'event-hackathon';
      case 'workshop':
        return 'event-workshop';
      case 'competition':
        return 'event-competition';
      default:
        return '';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="page-container">
      <section className="events-section">
        <div className="section-header">
          <Calendar className="section-icon" />
          <h2 className="section-title">Upcoming Events</h2>
          <p className="section-subtitle">Join us for exciting hackathons, workshops, and competitions</p>
        </div>

        <div className="events-grid">
          {events.map((event, index) => (
            <div
              key={event.id}
              className={`event-card ${getEventTypeClass(event.type)}`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="event-type-badge">{event.type}</div>

              <h3 className="event-title">{event.title}</h3>
              <p className="event-description">{event.description}</p>

              <div className="event-details">
                <div className="event-detail">
                  <Calendar size={18} />
                  <span>{formatDate(event.date)}</span>
                </div>
                <div className="event-detail">
                  <Clock size={18} />
                  <span>{event.time}</span>
                </div>
                <div className="event-detail">
                  <MapPin size={18} />
                  <span>{event.location}</span>
                </div>
                <div className="event-detail">
                  <Users size={18} />
                  <span>{event.attendees} registered</span>
                </div>
              </div>

              <a href={event.registrationLink} className="event-register-btn">
                <span>Register Now</span>
                <ExternalLink size={18} />
              </a>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
