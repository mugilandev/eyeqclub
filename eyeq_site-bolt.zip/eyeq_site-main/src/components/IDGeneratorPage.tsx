import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { CreditCard, Download, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const IDGeneratorPage: React.FC = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    department: '',
    studentId: '',
  });
  const [generatedId, setGeneratedId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const idData = JSON.stringify({
      ...formData,
      memberId: `EYEQ${Date.now()}`,
      generatedAt: new Date().toISOString(),
    });
    setGeneratedId(idData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleDownload = () => {
    const element = document.getElementById('id-card');
    if (!element) return;

    alert('ID Card download feature would be implemented with html2canvas or similar library');
  };

  return (
    <div className="page-container">
      <section className="id-generator-section">
        <div className="section-header">
          <CreditCard className="section-icon" />
          <h2 className="section-title">Member ID Generator</h2>
          <p className="section-subtitle">Generate your official EyeQ Club member ID with QR code</p>
        </div>

        <div className="id-generator-container">
          <form className="id-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="fullName">Full Name</label>
              <input
                type="text"
                id="fullName"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                required
                placeholder="Your full name"
              />
            </div>

            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="your.email@example.com"
              />
            </div>

            <div className="form-group">
              <label htmlFor="department">Department</label>
              <select
                id="department"
                name="department"
                value={formData.department}
                onChange={handleChange}
                required
              >
                <option value="">Select Department</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electronics</option>
                <option value="IT">Information Technology</option>
                <option value="EEE">Electrical Engineering</option>
                <option value="MECH">Mechanical Engineering</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="studentId">Student ID</label>
              <input
                type="text"
                id="studentId"
                name="studentId"
                value={formData.studentId}
                onChange={handleChange}
                required
                placeholder="Your student ID"
              />
            </div>

            <button type="submit" className="generate-button">
              <CreditCard size={20} />
              <span>Generate ID Card</span>
            </button>
          </form>

          {generatedId && (
            <div className="id-card-container">
              <div id="id-card" className="id-card">
                <div className="id-card-header">
                  <img src="/white.png" alt="EyeQ Club" className="id-card-logo" />
                  <h3>EyeQ Club</h3>
                  <p>SIMATS</p>
                </div>

                <div className="id-card-photo">
                  <User size={64} />
                </div>

                <div className="id-card-info">
                  <h4>{formData.fullName}</h4>
                  <p className="id-card-email">{formData.email}</p>
                  <div className="id-card-details">
                    <div className="id-detail">
                      <span className="detail-label">Department:</span>
                      <span className="detail-value">{formData.department}</span>
                    </div>
                    <div className="id-detail">
                      <span className="detail-label">Student ID:</span>
                      <span className="detail-value">{formData.studentId}</span>
                    </div>
                    <div className="id-detail">
                      <span className="detail-label">Member Since:</span>
                      <span className="detail-value">{new Date().getFullYear()}</span>
                    </div>
                  </div>
                </div>

                <div className="id-card-qr">
                  <QRCodeSVG
                    value={generatedId}
                    size={120}
                    level="H"
                    includeMargin={true}
                  />
                  <p>Scan for member profile</p>
                </div>

                <div className="id-card-footer">
                  <p>Valid for Academic Year 2025-2026</p>
                </div>
              </div>

              <button className="download-button" onClick={handleDownload}>
                <Download size={20} />
                <span>Download ID Card</span>
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
