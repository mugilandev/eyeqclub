import { useEffect, useState } from 'react';

export const useCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isClicking, setIsClicking] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseDown = () => {
      setIsClicking(true);
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZTRQKSK/j8L9oIQU1j9Py0oM0BxxpwO/lmk8TC0ax5O+8ZiEENYfT8dKENAYbaL7w5JdMEgpFruPwwGohBTGH0fPTgjMHH2i98N6VTBMJRKzj8MFrIQU1h9Ly0oM0BxxpwO/lmk8TC0Kx5O+7ZSEFNYfS8dKENAYbaL7w5JdMEgpGr+PwvmwhBTGH0fPUgjMHH2i98N+VTBMJRKzj8MFrIQU1h9Ly0oM0BxxpwO/lmk8TC0Kx5O+7ZSEFNYfS8dKENAYbaL7w5JdMEgpGr+PwvmwhBTGH0fPUgjMHH2i98N+VTBMJRKzj8MFrIQU1h9Ly0oM0Bxxpvu/lmk8TC0Kx5O+7ZSEFNYfS8dKENAYbaL7w5JdMEgpGruPwv2whBTGH0fPUgjMHH2i98N+VTBMJRKzj8MBrIQU1h9Ly0oM0BxxpwO/lmk8TC0Kx5O+7ZSEFNYfS8dKENAYbaL7w5JdMEgpGruPwv2shBTGH0fPUgjMHH2i98N+VTBMJRKzj8MBrIQU1h9Ly0oM0BxxpwO/lmk8TC0Kx5O+7ZSEFNYfS8dKENAYbaL7w5JdMEg==');
      audio.volume = 0.1;
      audio.play().catch(() => {});
      setTimeout(() => setIsClicking(false), 100);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mousedown', handleMouseDown);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mousedown', handleMouseDown);
    };
  }, []);

  return { position, isClicking };
};
