import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { CustomCursor } from './components/CustomCursor';
import { GeometricBackground } from './components/GeometricBackground';
import { Navigation } from './components/Navigation';
import { HomePage } from './components/HomePage';
import { ContactPage } from './components/ContactPage';
import { FAQPage } from './components/FAQPage';
import { LeaderboardPage } from './components/LeaderboardPage';
import { EventsPage } from './components/EventsPage';
import { IDGeneratorPage } from './components/IDGeneratorPage';
import { AuthPage } from './components/AuthPage';
import { ProfilePage } from './components/ProfilePage';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'contact':
        return <ContactPage />;
      case 'faq':
        return <FAQPage />;
      case 'leaderboard':
        return <LeaderboardPage />;
      case 'events':
        return <EventsPage />;
      case 'id-generator':
        return <IDGeneratorPage />;
      case 'auth':
        return <AuthPage onSuccess={() => setCurrentPage('home')} />;
      case 'profile':
        return <ProfilePage onLogout={() => setCurrentPage('home')} />;
      default:
        return <HomePage />;
    }
  };

  return (
    <AuthProvider>
      <CustomCursor />
      <GeometricBackground />
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />
      {renderPage()}
    </AuthProvider>
  );
}

export default App;
