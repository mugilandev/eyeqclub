export interface User {
  id: string;
  email: string;
  fullName: string;
  role: 'member' | 'admin' | 'bearer';
  avatarUrl?: string;
  linkedin?: string;
  instagram?: string;
  whatsapp?: string;
  points: number;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  eventDate: string;
  imageUrl?: string;
  registrationLink?: string;
}

export interface LeaderboardEntry {
  id: string;
  user: User;
  activity: string;
  pointsEarned: number;
  createdAt: string;
}

export interface DailyUpdate {
  id: string;
  title: string;
  description: string;
  postedBy: User;
  createdAt: string;
}
